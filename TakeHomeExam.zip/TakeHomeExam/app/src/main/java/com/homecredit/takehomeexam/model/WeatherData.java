package com.homecredit.takehomeexam.model;

public class WeatherData {

    public String id = "";
    public String main = "";
    public String description = "";
    public String icon = "";
}
