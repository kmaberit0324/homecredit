package com.homecredit.takehomeexam.util;

import android.view.View;

public interface ClickListener {

    void OnClick(View view, int position);
}
