package com.homecredit.takehomeexam.model;

public class Main {

    public String temp = "";
    public String pressure = "";
    public String humidity = "";
    public String temp_min = "";
    public String temp_max = "";

}
