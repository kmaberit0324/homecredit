package com.homecredit.takehomeexam.model;

public class Wind {

    public String speed = "";
    public String deg = "";
}
