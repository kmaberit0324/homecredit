package com.homecredit.takehomeexam.volleyinterface;

import org.json.JSONObject;

public interface OpenWeatherInterface {

    public void result(String response);
    public void error(String error);
}
