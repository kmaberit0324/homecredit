package com.homecredit.takehomeexam.model;

public class Sys {

    public String type = "";
    public String id = "";
    public String message = "";
    public String country = "";
    public String sunrise = "";
    public String sunset = "";

}
