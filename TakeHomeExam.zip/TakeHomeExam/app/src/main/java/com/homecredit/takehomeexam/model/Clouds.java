package com.homecredit.takehomeexam.model;

class Clouds {

    public String all = "";
}
