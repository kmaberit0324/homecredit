package com.homecredit.takehomeexam.model;

public class Coord {

    public String lat = "";
    public String lon = "";
}
